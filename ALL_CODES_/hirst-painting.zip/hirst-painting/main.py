import turtle as t
import random

t.colormode(255)

tim = t.Turtle()
tim.speed("fastest")
tim.penup()
tim.hideturtle()

color_list = [(208, 156, 107), (124, 172, 194), (30, 115, 154),
              (131, 180, 152), (144, 82, 55), (230, 202, 115), (205, 135, 151), (157, 59, 79), (208, 76, 96),
              (40, 130, 87), (222, 80, 59), (179, 154, 53), (66, 162, 115), (236, 161, 173), (164, 28, 45),
              (35, 161, 190),
              (164, 207, 185), (14, 48, 75), (233, 170, 160), (15, 97, 64), (150, 33, 26), (19, 64, 45), (71, 31, 46),
              (7, 93, 109),
              (159, 205, 214), (80, 73, 34), (27, 62, 118), (179, 189, 210), (109, 124, 161), (236, 200, 10)]

tim.setheading(225)
tim.forward(300)
tim.setheading(0)
number_of_dots = 100

for dot_count in range(1, number_of_dots+1):
    tim.dot(20, random.choice(color_list))
    tim.forward(50)

    if dot_count % 10 == 0:
        tim.setheading(90)
        tim.forward(50)
        tim.setheading(180)
        tim.forward(500)
        tim.setheading(0)

screen = t.Screen()
screen.exitonclick()
